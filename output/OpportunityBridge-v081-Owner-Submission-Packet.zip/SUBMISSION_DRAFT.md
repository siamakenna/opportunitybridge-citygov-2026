# Existing Kenny! draft — v0.8.1

Original title: OpportunityBridge — From Education to Real Civic Careers, With Evidence

SOLUTION DESCRIPTION

OpportunityBridge: Career Constellation helps learners turn unfamiliar public-service opportunities into a small learning action, source-linked evidence and a concrete human conversation. Education and classroom projects do not automatically translate into understandable employer requirements. The prototype makes that translation inspectable without an account or fee, while preserving missing information and employer authority.

Career Constellation is its signature experience. A learner selects an interest and explores two alternative routes through Discover, Learn, Practice, Build, Prepare and Connect. Each node opens actual source content, a public learning resource, a working quest, an Evidence Passport, Advisor Studio or the official application/program route. A text/list equivalent offers the same actions. Nothing requires earlier gameplay or predicts employment suitability. Route explanations distinguish published duties from illustrative learning analogies, including separate frozen examples.

Three playable quests remain central. Source Detective uses a frozen Maryland Administrative Specialist I announcement: identify the thirty-accredited-credit substitution for six administrative months, select official evidence, recognize missing applicant facts and reject a hiring guarantee. All five checks must pass. Accessibility Artifact Builder changes five concrete issues in a fictional library preview and exports repaired HTML. Career Evidence Builder connects fictional experience to a skill, a valid MPT duty/condition, a proposed artifact and a human-verification question. Empty or invalid chains cannot complete it. No exercise certifies employer eligibility or accessibility compliance.

Versioned learning records retain actual checks and source snapshots. Repeated clicks cannot farm rewards; plain learning view hides points. Successful exercises transfer into editable Passport fields. JSON/Markdown preserve source identity, review date, quest provenance, proposed work and unknowns. Historical NIH deliverables and former Civic Innovation Corps accounts are attributed examples from other programs, never product testimonials.

Saving is explicitly optional and off by default. After consent, this browser can retain interests, saved source URLs, route, learning records and milestones. Fictional Passport drafts require a separate capture button; private applicant facts, contact details and document confirmations are excluded. Welcome-back summaries and remaining actions support return visits. Clear Saved Journey and opt-out remove saved app data; full reset also clears working drafts. Strict versioned JSON import rejects unsafe or incompatible content, marks imported progress unverified and grants no XP until replay. Nothing is silently uploaded or cloud-synced; shared-device and storage-loss limits are visible.

Supporting discovery uses Maryland’s advertised RSS, twelve curated catalog records, five individually reviewed learning resources and three separately counted directory routes. Two new official W3C guides support accessibility practice. Earn, Learn, Build Experience and Explore groups show actual individual/directory counts. Explained interest/source ordering is deterministic, with neutral date/title options. INTERNAL is not an internship; graduate alone is not entry-level; contractual does not mean short-term. Unknown pay stays unknown. No individual short paid project was verified, so the empty state retains its Parker Dewey directory fallback.

Daily observations publish permitted metadata and source holds without approving qualification mappings or renewing original review dates. Repeated frozen software trials exercise discovery, quests, Passport, save/reload, export, deletion, import and reset. Actual downloads are inspected. These are software checks, not user outcomes: independent unfamiliar participants remain n=0. A voluntary fifteen-minute study kit is prepared but unsent. The proposed sixty-day campus/municipal pilot needs willing hosts, consenting adults and independent adjudication; career, access and return benefits remain hypotheses.

EQUITY STATEMENT

OpportunityBridge makes an explanation often supplied through professional networks available without charging learners or requiring accounts. That is an access hypothesis, not proof that an employment gap has closed. Discovery categories describe sources rather than people; skills and preferred experience never become certified eligibility or a hiring score.

Saving is off by default. Fictional drafts require explicit capture; shared-device risks, deletion and unverified imports are visible. No private resumes or applicant records belong in this public demo. The proposed pilot provides equivalent source packets, human advising, compensation and accommodations in manual and assisted conditions. Adult consent is voluntary and separate from services, grades and hiring. Paper, telephone/in-person support and devices should be available through a host; contact linkage stays in approved institutional systems.

Semantic labels, visible focus, a text/list Constellation, reduced-motion rules, narrow-screen reflow and readable exports support access. Tool-driven checks are documented; English-only content and absent independent assistive-technology testing remain limits. No WCAG certification is claimed. We would preserve incomplete tasks, negative feedback, barriers and exact denominators. A small pilot cannot establish subgroup parity or causal hiring effects. Historical fellows are not product users or endorsers.

PILOT AND MEASURES

Proposed: sixty days, twenty-five consenting adults and twenty-five double-reviewed opportunities. Six staff functions cover campus advising, municipal source adjudication, content stewardship, maintenance, evaluation and accessibility. The existing manager PDF, interactive partner route, checklists, anonymous worksheet and blank two-rater tracking CSV remain available. No institution, funds or labor are committed.

Illustrative cost: 112 staff hours/$5,740 plus $375 compensation and $125 materials/access reserve; $6,240 economic total. Cash can be $500 only if all labor is contributed. Host approval must validate rates, capacity, overhead and accommodations. Minimize data; delete contact linkage/raw feedback within ninety days unless approved policy requires otherwise.

Targets, not results: at least 90% criterion/source correctness and zero false definite eligibility claims; at least 80% actionable plans scoring 4/5; at least 60% reported fourteen-day follow-through, separating self-report from advisor confirmation; zero unresolved blocking access barriers and median advisor review at most 15 measured minutes.

EVIDENCE, MEDIA AND DISCLOSURE

Executed checks and failures are linked in the release report. Independent n=0; no causal speed or hiring gain. Source-backed AI-assisted reviews are not independent HR validation. Daily metadata updates do not replace explicit source review near submission. The unavailable v0.3 Impact Lab was not integrated and its reported 17 tests are not claimed. Internal ten-criterion mock assessment remains 87/100; the owner-reported external automated estimate was approximately 85/100; additional features do not substitute for independent impact, accessibility or partner evidence.

The current 180-second v0.8.1 walkthrough uses seven authentic working-app captures assembled as a captioned screenshot sequence, not continuous footage. It shows Career Constellation, genuine practice, Passport and optional save/return, and preserves capture-time source dates. English captions/transcript are provided; the earlier video is retained. No narration, fabricated participants or testimonials. The 5–7-minute finalist pitch and Q&A are prepared.

ChatGPT supplied the starter; Codex significantly assisted research, code, design, deterministic workflows, evaluation, documents, testing, media and publication. Owner review remains necessary. MIT source; static browser runtime, system fonts, public RSS, Node/Python tests and GitHub Pages. No paid API or live language-model agent. Prior-project methods were adapted from the brief without copying private code, data or branding. Official publishers retain their source materials.

TEAM: Kenny!; captain Makenna Rodriguez; one registered member. Existing team, registration and eligibility metadata preserved. Saved draft only; not submitted for judging.

DEMO: https://siamakenna.github.io/opportunitybridge-citygov-2026/
GUIDE/SOURCES: https://siamakenna.github.io/opportunitybridge-citygov-2026/judge.html
WALKTHROUGH: https://siamakenna.github.io/opportunitybridge-citygov-2026/walkthrough.html
EVALUATION: https://siamakenna.github.io/opportunitybridge-citygov-2026/evaluation.html
PILOT: https://siamakenna.github.io/opportunitybridge-citygov-2026/pilot.html
SOURCE: https://github.com/siamakenna/opportunitybridge-citygov-2026


Save Draft only. Original title, three URL fields, pilot PDF, team and eligibility metadata remain. No final submission or new agreement.
