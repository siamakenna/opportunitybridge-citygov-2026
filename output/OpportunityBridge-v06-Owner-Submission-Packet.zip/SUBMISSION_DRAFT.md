# Kenny! v0.6 — owner review copy

SOLUTION DESCRIPTION

OpportunityBridge helps learners translate education and experience into a credible public-service application or advisor conversation. Job titles and qualification language can be unfamiliar, and an informal professional connection often supplies the explanation. Our prototype makes the source, selected conditions, missing information and proposed evidence visible. Students, recent graduates and career changers can inspect the same workflow without an account or fee.

The working application begins with official opportunities. Its twelve-record inventory distinguishes five specific Maryland recruitments, two dated research intakes, four ongoing career/search pathways and one expired intake. These are not twelve open jobs. Every record retains its original source, recruitment identity when applicable, location, published compensation, deadline and review date. A newly inspected MDE Administrative Specialist III recruitment closes November 9. Together with two open/continuous Maryland Public Television fellowships and the NIH and DOE summer research intakes, it provides five deadline-compatible options beyond November 6, subject to withdrawal and reinspection.

A featured Maryland Public Television Media Literacy Student Fellow journey makes the process concrete. The card shows $15.50/hour, the student/recent-graduate route, minimum sixteen-hour weekly commitment and an expandable four-item college-document list. Visitors can inspect the complete original announcement without losing their place. A skippable four-step tour demonstrates source inspection, fictional declarations, evidence preparation and a human conversation. Five linked workspace stages keep progress, possible conflicts and unknown information visible.

Qualification explanations remain conservative. The Maryland administrative card exposes six qualifying months or thirty accredited college credits and provides an “I have college credits — inspect substitution” shortcut to the numeric input. The fiscal record explains that six accounting credits replace only one of two required years. Military, vocational and ambiguous equivalencies require employer review; substitutions are not silently stacked. MPT role duties are distinguished from minimum qualifications, and its selected condition remains a human-review prompt. No overall applicant eligibility is certified.

The editable evidence worksheet connects fictional experience to a skill, a selected source requirement or role task, a proposed artifact and a human-verification question. A classroom HTML project could lead to a proposed accessible educational resource demonstration. That suggestion is not proof of completed work. Visitors can add connections, mark documents prepared, reset, print full-text snapshots and download an advisor handoff containing edited facts, source provenance, unresolved questions and deadline-aware preparation targets. Continuous recruitment receives personal targets, never an invented employer closing date. No application or message is sent.

Source maintenance separates observation from approval. Public retrieval checks produce a prioritized queue for changed content, recruitment discrepancies, withdrawal, missing excerpts, expired deadlines, stale reviews and unavailable sources. A daily GitHub workflow creates reports and artifacts with read-only repository permission. It cannot approve mappings, renew dates or publish changes. Explicit source-specific review requires findings, actual inspection time and matching source/mapping hashes. Failed retrievals remain disclosed. The static app suppresses positive interpretations after forty-eight hours and preserves passed deadlines in history.

Five attributed historical civic-career examples distinguish institutional deliverable reports from first-person accounts, offers and contractor work. They illustrate other programs, not OpportunityBridge users or endorsements. Practice Mode separately preserves the fictional baseline. A matched-source guided evaluation offers dated Maryland and continuous MPT pairs, counterbalanced order, actual intervals, missing-response denominators, negative feedback and optional host adjudication. Independent unfamiliar participants remain n=0; career benefit and faster advising remain hypotheses. A proposed sixty-day campus/municipal pilot would test twenty-five adults and twenty-five reviewed opportunities. Working software and genuine downloads are the present achievement; independent people, source adjudication and willing institutions must supply the next evidence.

EQUITY STATEMENT

The prototype makes an explanation often supplied through professional networks available without charging learners, requiring an account or collecting resumes. That is an access hypothesis, not evidence that an employment gap has closed. Preferred skills and related experience never become certified eligibility. The tool does not rank people by protected characteristics or demographic proxies.

The proposed pilot offers equivalent source packets, human advising, compensation and accommodations in manual and assisted conditions. Participation is voluntary, adult-only and separate from services, grades and hiring. Paper worksheets, telephone/in-person help and devices should be available through a host. Only fictional circumstances enter this public app; consent/contact linkage stays separately in approved institutional systems.

The interface supports keyboard navigation, visible focus, labeled controls/errors, narrow-screen reflow, reduced motion and full-text printable/downloadable handoffs. Selected rendered contrast checks passed. English-only content, no independent assistive-technology study and no WCAG certification remain limits. We would report missing work, withdrawals, assistance, misunderstandings, negative findings and access barriers with exact denominators. A small pilot cannot establish subgroup parity or causal hiring effects. Historical fellows are never presented as product testimonials.

PILOT, COST AND MEASURES

Proposed: sixty days, twenty-five consenting adults, twenty-five double-reviewed sources. College career services recruits/advises; municipal HR validates complete source conditions; a steward, maintainer, evaluator and accessibility reviewer own updates, defects, scoring and alternatives. The interactive partner walkthrough and downloadable kit provide onboarding/source checklists, a blank outcome CSV, anonymous worksheet, weekly schedule, consent/invitation instructions and escalation rules. No host, funds or labor are committed.

Illustrative cost:112 staff hours/$5,740 plus $375 compensation and $125 materials/access reserve; $6,240 total economic cost. Cash can be $500 only if all labor is contributed; validate rates, overhead and accommodations. Delete contact linkage/raw feedback within ninety days unless approved policy requires otherwise.

Proposed targets: at least90% criterion/source correctness and zero false definite eligibility claims; at least80% actionable plans scoring4/5; at least60% reported fourteen-day follow-through, separating self-report from advisor confirmation; zero unresolved blocking barriers and median advisor review at most15 measured minutes. Targets are not results.

EVIDENCE, PRESENTATION AND DISCLOSURE

Executed software checks:80 Node tests;47 preserved and25 added browser assertions;8 frozen real-source fixtures and12 fictional judgments. Independent unfamiliar participants n=0. Source-backed AI-assisted reviews are not independent HR validation. Five automated source fetch failures remain reported; NIH SIP was separately read through its official page. The unavailable v0.3 Impact Lab was not integrated and its reported17 tests are not claimed.

The retained150-second captioned video is an authentic v0.4 screenshot sequence, not continuous footage. Synchronized large captions and a current live MPT walkthrough complement it. Supported capture tools do not provide continuous recording. The5–7-minute finalist pitch/Q&A is prepared. Internal mock87/100 is subjective, not an official score.

ChatGPT supplied the starter; Codex significantly assisted code, design, official-source research, historical summaries, evaluation, documents, browser QA, media assembly and publication. Owner review remains necessary. MIT source; browser-native runtime, system fonts, Node tests and GitHub Pages. Official publishers retain their materials. No invented participants, credentials, testimonials or employment results.

TEAM: Kenny!; captain Makenna Rodriguez; one registered member. Existing registration/eligibility metadata preserved. Saved draft only; not submitted for judging.

DEMO: https://siamakenna.github.io/opportunitybridge-citygov-2026/
GUIDE/SOURCES: https://siamakenna.github.io/opportunitybridge-citygov-2026/judge.html
PARTNER KIT: https://siamakenna.github.io/opportunitybridge-citygov-2026/pilot.html
EVALUATION: https://siamakenna.github.io/opportunitybridge-citygov-2026/evaluation.html
PILOT PDF: https://siamakenna.github.io/opportunitybridge-citygov-2026/output/pdf/OpportunityBridge-Pilot-Packet.pdf
WALKTHROUGH: https://siamakenna.github.io/opportunitybridge-citygov-2026/walkthrough.html
SOURCE: https://github.com/siamakenna/opportunitybridge-citygov-2026
